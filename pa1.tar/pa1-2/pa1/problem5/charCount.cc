#include "charCount.h"
#include <iostream>
using namespace std;

// implement these functions
void countCharacters(const string &input, int counts[26]) {
    // write your code here!
}

void printCounts(const int counts[26]) {
    // write your code here!
}
