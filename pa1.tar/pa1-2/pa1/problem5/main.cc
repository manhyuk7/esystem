#include <iostream>
#include <string>
#include "charCount.h"

using namespace std;

int main() {
    string sentence;
    getline(cin, sentence);

    int counts[26] = {0};

    // you should call countCharacters function
    // you should call printCounts function

    return 0;
}
