#include "wordProcess.h"

std::string cpe::getMostPairsWord(std::string words[2500])
{
  //write your code here!
  return "";
}
